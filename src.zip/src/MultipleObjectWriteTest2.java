
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

import com.fourcolors.SavingsAccount;


public class MultipleObjectWriteTest2 {
    public static void main(String[] args) {
        try {
            System.out.println("Trying to create an object..");

            SavingsAccount savObj1= new SavingsAccount(101,"Julia",50000,1234);
            SavingsAccount savObj2= new SavingsAccount(102,"Julie",60000,3234);
            SavingsAccount savObj3= new SavingsAccount(103,"Janet",70000,4234);
            SavingsAccount savObj4= new SavingsAccount(104,"Jane",80000,5234);
            SavingsAccount savObj5= new SavingsAccount(105,"Juhee",90000,7234);
            
            System.out.println("sav Obj1 "+savObj1);
            System.out.println("sav Obj2 "+savObj2);
            System.out.println("sav Obj3 "+savObj3);
            System.out.println("sav Obj4 "+savObj4);
            System.out.println("sav Obj5 "+savObj5);
            
            System.out.println("objects..are...created...");
            ArrayList<SavingsAccount> allAccounts = new ArrayList<SavingsAccount> ();
            
            allAccounts.add(savObj1);
            allAccounts.add(savObj2);
            allAccounts.add(savObj3);
            allAccounts.add(savObj4);
            allAccounts.add(savObj5);
            
            
            System.out.println("objects..are collected inside ArrayList...");

            FileOutputStream fout = new
                    FileOutputStream("Savings3.txt", true);
            System.out.println("File is created....");

            ObjectOutputStream oos = new ObjectOutputStream(fout); //pass fout here
            System.out.println("Object output stream is ready to write the  objects.......");

            System.out.println("Trying to write the ArrayList object...");
            oos.writeObject(allAccounts); //OH!!! private data is stolen to write to the disk....very bad
         
            
            System.out.println("ArrayList Object is written to the disk....");

            oos.close();
            fout.close();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

}
/*
    Java Objects / data used here in Java is in the memory
    memory is volatile
    we want to store our java data on a device
    in the form of a file or a database row

                Java Objects / DATA
                        |
             ----------------------
                |               |
                File            Database
                |


          Read the file         Write to the file
          |                     |
          input stream          output stream


                    Java i/o
                     |
              ------------------
              |                 |
            byte based       character based
            1 byte             1 char = 2 bytes
            |                   |
            ASCII               UNICODE
            |                   |
            256 english         international letters
            letters             65535 ( first 256 ASCII )
                |                       |
       -------------            -----------------
       |        |                   |           |
 InputStream   OutputStream         Reader      Writer <-- abstract parents
 |  read()          |write()        |            |
 FileInputStream FileOutputStream  FileReader   FileWriter


An interface without any method is known as MARKER interface
it simply marks a contract of its functionality to the JVM



























 */