
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.fourcolors.SavingsAccount;


public class MultipleObjectReadTest2 {
    public static void main(String[] args) {
        try {
            System.out.println("Trying to create an object..");

        
            ArrayList<SavingsAccount> allAccounts = new ArrayList<SavingsAccount> ();
            
          
            FileInputStream fin = new
                    FileInputStream("Savings3.txt");
            System.out.println("File is ready........");

            ObjectInputStream ois = new ObjectInputStream(fin); //pass fin here
            System.out.println("Object input stream is ready to read the  objects.......");

            System.out.println("Trying to read the ArrayList...");
            allAccounts= (ArrayList<SavingsAccount>) ois.readObject(); //OH!!! private data is stolen to write to the disk....very bad
            
            
            System.out.println("ArrayList is read from the disk....");
            
            		Iterator<SavingsAccount> iter = allAccounts.iterator();
            		
            		while(iter.hasNext()) {
            			SavingsAccount savAcc = iter.next();
            			System.out.println("sav Acc : "+savAcc);
            		}

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }

}
/*
    Java Objects / data used here in Java is in the memory
    memory is volatile
    we want to store our java data on a device
    in the form of a file or a database row

                Java Objects / DATA
                        |
             ----------------------
                |               |
                File            Database
                |


          Read the file         Write to the file
          |                     |
          input stream          output stream


                    Java i/o
                     |
              ------------------
              |                 |
            byte based       character based
            1 byte             1 char = 2 bytes
            |                   |
            ASCII               UNICODE
            |                   |
            256 english         international letters
            letters             65535 ( first 256 ASCII )
                |                       |
       -------------            -----------------
       |        |                   |           |
 InputStream   OutputStream         Reader      Writer <-- abstract parents
 |  read()          |write()        |            |
 FileInputStream FileOutputStream  FileReader   FileWriter


An interface without any method is known as MARKER interface
it simply marks a contract of its functionality to the JVM



























 */