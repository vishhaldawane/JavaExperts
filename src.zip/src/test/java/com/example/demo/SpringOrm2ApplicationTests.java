package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Department;
import com.example.demo.layer3.DepartmentRepository;
import com.example.demo.layer3.DepartmentRepositoryImpl;

@SpringBootTest
class SpringOrm2ApplicationTests {

	@Autowired
	DepartmentRepositoryImpl deptRepo;
	
	@Test
	void insertDeptTest() {
		Department dept = new Department();
		dept.setDepartmentNumber(375);
		dept.setDepartmentName("QMS");
		dept.setDepartmentLocation("Mumbai");
		
		deptRepo.insertDepartment(dept);
	}
	
	@Test
	void updateDeptTest() {
		Department dept = new Department();
		dept.setDepartmentNumber(380);
		dept.setDepartmentName("Testing");
		dept.setDepartmentLocation("Bangalore");
		
		deptRepo.updateDepartment(dept);
	}
	
	@Test
	void selectDeptTest() {
		Department dept ;
		dept = deptRepo.selectDepartment(375);
		System.out.println("Dept no   : "+dept.getDepartmentNumber());
		System.out.println("Dept name : "+dept.getDepartmentName());
		System.out.println("Dept loc  : "+dept.getDepartmentLocation());
		
	}
	
	
	@Test
	void deleteDeptTest() {
		
		deptRepo.deleteDepartment(380);
		

		
	}
	
	@Test
	void selectAllDeptTest() {
		List<Department> deptList ;
		deptList = deptRepo.selectDepartments();
		for(Department dept : deptList) {
			System.out.println("Dept no   : "+dept.getDepartmentNumber());
			System.out.println("Dept name : "+dept.getDepartmentName());
			System.out.println("Dept loc  : "+dept.getDepartmentLocation());
		}
	}
	
}
/*
 
 					Spring-ORM2
 						|
 				-------------------
 				|
 				src
 				|
 	------------------------------
 	|							|
 	main						test
 	|							|
 	-------------				-----
 	|			|				|
 	java		resources		java
 	|				  |			|
  	com.example.demo  |			|
 	SpringOrm2        |			|
 	Application		  |			|
 				      |			|
	layer1 - TBL	app.pro		SpringOrm2ApplicationTests
 	layer2 - POJO					@Test
 	layer3 - REPO					void insertDeptTest() { }
 	layer4 - SERVICE					... .. ... ... 
 	layer5 - CONTROLLER
 
  
  
  
  
*/
