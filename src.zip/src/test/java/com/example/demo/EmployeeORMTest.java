package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Department;
import com.example.demo.layer2.Employee;
import com.example.demo.layer3.DepartmentRepository;
import com.example.demo.layer3.DepartmentRepositoryImpl;
import com.example.demo.layer3.EmployeeRepositoryImpl;

@SpringBootTest
class EmployeeORMTest {

	@Autowired
	EmployeeRepositoryImpl empRepo;
	
		
	@Test
	void selectAllDeptTest() {
		List<Employee> empList ;
		empList = empRepo.selectEmployees();
		for(Employee emp : empList) {
			System.out.println("emp no   : "+emp.getEmployeeNumber());
			System.out.println("emp name : "+emp.getEmployeeName());
			System.out.println("emp job  : "+emp.getEmployeeJob());
			System.out.println("emp doj  : "+emp.getHiredate());
			System.out.println("emp mgr  : "+emp.getManagerCode());
			System.out.println("emp sal  : "+emp.getSalary());
			System.out.println("emp com  : "+emp.getCommision());
			System.out.println("emp dno  : "+emp.getDepartmentNumber());
			System.out.println("-------------");
		}
	}
	
}
/*
 
 					Spring-ORM2
 						|
 				-------------------
 				|
 				src
 				|
 	------------------------------
 	|							|
 	main						test
 	|							|
 	-------------				-----
 	|			|				|
 	java		resources		java
 	|				  |			|
  	com.example.demo  |			|
 	SpringOrm2        |			|
 	Application		  |			|
 				      |			|
	layer1 - TBL	app.pro		SpringOrm2ApplicationTests
 	layer2 - POJO					@Test
 	layer3 - REPO					void insertDeptTest() { }
 	layer4 - SERVICE					... .. ... ... 
 	layer5 - CONTROLLER
 
  
  
  
  
*/
