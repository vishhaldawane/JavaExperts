package com.example.demo;

import java.time.LocalDate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOrm2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringOrm2Application.class, args);
		System.out.println("Spring ORM2 app started....");
		
		
		LocalDate   ld = LocalDate.of(1999, 12, 28);
		
		System.out.println("local date is "+ld);
		System.out.println("year  : "+ld.getYear());
		System.out.println("month : "+ld.getMonth());
		System.out.println("day   : "+ld.getDayOfMonth());	
		
		
		
	}

}
