package com.example.demo.layer2;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
/*
  
  DEPT
   pk
   1		2			3		?????
   deptno	dname		loc   no4th column
   10       IT          NY
   
   
   EMP
   PK							FK
   empno	ename	job  ...   dno
   7849							10
   2773							10
   2838							10
 
     "One" Department can have "Many" Employees
 
 1. Unnormalized data
 2. Normalization
 
 3. ER Diagram - Entity Relationship diagram
 4. find out the the relationship across the entties
 5. POJO - interrelated 
 
 
 One  BankAccount 
 Many Payee
 
 bankaccount
 acno	name	balance
 101	jack
 102	jane
 103	jill
 
 
 payee
 --------
 payeeid	payeename	payeeacno	ifsc	ano
 1			smith		445			..		101	
 2			robert		444			..		101
 3			julie		333			..		101
 
 
 
 */
@Entity
@Table(name="dept5")
public class Department {

	@Id
	@Column(name="deptno") //1
	private int departmentNumber;
	
	@Column(name="dname") //2
	private String departmentName;
	
	@Column(name="loc")//3
	private String departmentLocation;
	
	@OneToMany // only relationship - no 4th column 
	Set<Employee> empSet = new HashSet<Employee>();

	
	public Set<Employee> getEmpSet() {
		return empSet;
	}
	public void setEmpSet(Set<Employee> empSet) {
		this.empSet = empSet;
	}
	public int getDepartmentNumber() {
		return departmentNumber;
	}
	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getDepartmentLocation() {
		return departmentLocation;
	}
	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}
	
	
	
}


/*

@Entity
@Table(name="dept5")
class Dept
{
 	@Id <-- Pk
 	@Column("deptno") int departmentNumber 
 	
 	@Column String dname 
 	@Column String dloc
 	
 	@OneToMany
	private Set<Employee> staff = new HashSet<Employee>();
	
}
Employee e1; e2; e3 .... setters of e1,e2,e3
Dept d = new Dept(); d.se 10 ACC NY
d.staff.add(e1);
d.staff.add(e2);
d.staff.add(e3);

em.persist(d);
---

Dept d = em.find(Dept.class,10);

Set myset = d.getStaff()

@Table(emp
class Employee extends Dept //wrong way 
{
	@Id
	int empno	
	
	ename job sal
	
	@JoinColumn(name="dno")
	private int departmentNumber;
}

class Report
class Student 
{
   ArrayList<Report> reportCards = new Report();
   
}
one department can have many employees
onetomany

	dept <--parent table		
	PK
	deptno	dname  loc
	10		ACCS   NY <-- row(DB) / obj(ORM)
	20		IT
	30		SALES
	
	emp <-- child table
	PK					   (FK)
	empno	ename job sal  dno
	102		jack  acc 505	10
	202		jane  dev 600   20
	333		jill  sal 600   30
	444		joby  cle 800   10
	
	BUS DEV EXE -> client
	
	
	Developer
	tester
	project manager
	|
	bus dev executive
	|
	pampers <-- client
	|
	




*/