
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.fourcolors.SavingsAccount;


public class MultipleObjectReadTest {
    public static void main(String[] args) {
        try {
            System.out.println("Trying to create an object..");

            SavingsAccount savObj1=  null;
            SavingsAccount savObj2=  null;
            SavingsAccount savObj3=  null;
            SavingsAccount savObj4=  null;
            SavingsAccount savObj5=  null;
            
            System.out.println("sav Obj1 "+savObj1);
            System.out.println("sav Obj2 "+savObj2);
            System.out.println("sav Obj3 "+savObj3);
            System.out.println("sav Obj4 "+savObj4);
            System.out.println("sav Obj5 "+savObj5);
            
            System.out.println("objects..refs...created...");

            FileInputStream fin = new
                    FileInputStream("Savings2.txt");
            System.out.println("File is ready........");

            ObjectInputStream ois = new ObjectInputStream(fin); //pass fin here
            System.out.println("Object input stream is ready to read the  objects.......");

            System.out.println("Trying to read the objects...");
            savObj1=(SavingsAccount) ois.readObject(); //OH!!! private data is stolen to write to the disk....very bad
            savObj2=(SavingsAccount) ois.readObject();
            savObj3=(SavingsAccount) ois.readObject();
            savObj4=(SavingsAccount) ois.readObject();
            savObj5=(SavingsAccount) ois.readObject();
            
            System.out.println("Objects are read from the disk....");
            
            System.out.println("sav Obj1 "+savObj1);
            System.out.println("sav Obj2 "+savObj2);
            System.out.println("sav Obj3 "+savObj3);
            System.out.println("sav Obj4 "+savObj4);
            System.out.println("sav Obj5 "+savObj5);

            ois.close();
            fin.close();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }

}
/*
    Java Objects / data used here in Java is in the memory
    memory is volatile
    we want to store our java data on a device
    in the form of a file or a database row

                Java Objects / DATA
                        |
             ----------------------
                |               |
                File            Database
                |


          Read the file         Write to the file
          |                     |
          input stream          output stream


                    Java i/o
                     |
              ------------------
              |                 |
            byte based       character based
            1 byte             1 char = 2 bytes
            |                   |
            ASCII               UNICODE
            |                   |
            256 english         international letters
            letters             65535 ( first 256 ASCII )
                |                       |
       -------------            -----------------
       |        |                   |           |
 InputStream   OutputStream         Reader      Writer <-- abstract parents
 |  read()          |write()        |            |
 FileInputStream FileOutputStream  FileReader   FileWriter


An interface without any method is known as MARKER interface
it simply marks a contract of its functionality to the JVM



























 */