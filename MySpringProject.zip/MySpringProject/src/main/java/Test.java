import com.java.Car;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//IOC - Inversion of Control - Covid Vaccine  vs 		Drugs	/	Insulin
	//DI
public class Test {
	public static void main(String[] args) {

		System.out.println("=>Loading application Context...");
		ApplicationContext container = new
				ClassPathXmlApplicationContext("spring1.xml");
		System.out.println("=>Loaded the container....."+container);

		//Car myCar = (Car) container.getBean("carObj1"); //spring container will get the object for us
		//myCar.startCar();
		
	}
}
/*
 * 
 * The scope of this bean: 
 * typically "singleton" (one shared instance, which will be returned by all calls to getBean with the 
 given id), 
 or "prototype" (independent instance resulting from each call to getBean).
 
  By default, a bean will be a 
 singleton, unless the bean has a parent bean definition in which case it 
 will inherit the parent's scope. 
 
 Singletons are 
 most commonly used, and are ideal for multi-threaded service objects. 
 
 Further scopes, such as "request" or "session", 
 might be supported by extended bean factories (e.g. in a web environment). 
 
 Inner bean definitions inherit the singleton 
 status of their containing bean definition, unless explicitly specified:
 The inner bean will be a singleton if the containing 
 bean is a singleton, and a prototype if the containing bean has any other scope.

 * 
 */
//approach1
		//Piston p1 = new Piston();
		//Engine e1 = new Engine(p1); //Engine is dependent upon Piston
		
		//Car myCar = new Car(e1); //Car is dependent upon Engine 
		
		//myCar.startCar();


/*
			
						Java Technology
							|
			-------------------------------------
			|				|				|
			JSE				JEE				JME
			|				|				|
			corejava		enterprise		mobile
			|					|
	lang fundas				-------------
	oops concepts			|			|
	packages			   WEB			Enterprise [Java Components]=class (EJB)
	exceptions				|						|
	multithreading		Servlets/JSP	------------------------------
	generics			Angular-UI		|			|			| JMS
	collections							Session		Entity		Message
	jdbc								|			|				|
										Spring		Hibernate/JPA	|	
makemytrip							    |				|				|
	|							----------------	-----------		---------
	Home						|			|		|		|		|		|
	|						Stateless	Stateful	jdbc	ORM		SMS		Email
	cab/taxi
	|
	flight/railway
	|
	taxi
	|
	hotel ---> clientPlace															layer1 -DB
																						|
									layer5 --> [ layer 4 ] -- repo [ layer 3 - pojo - layer 2]
							Server[spring web app]				
							| makemytrip.com/app 
							|
				-----------------------
				|	|	|	|	|	|
				cl1 c2	c3	c4............layer 6
				|
				signup
				signin
				
	"Enterprise" features
	-----------
	1. RC - networking
	2. HA - clustering
	3. MT - threading
	4. POR - pooling
	5. COR - caching
	6. TM - ACID
	7. SM - https
	
	
			How a glider can become an Aircraft???
			
			
			
			
			
			
			
		Your First Spring Project /app
			
			
			Mavan Project
				|
		--------------------------------
		|			|				|
		src			spring1.xml		pom.xml
		|				|				|
----------------		conf			spring-core, spring-context
|			|			of
main		test		carObj->Car, eng)bj->Engine, pistObj->Piston 
|			|			with xml <bean> tags
java		java	
|
Car
Engine
Piston
Test				
|
ApplicationContext  ctx = new ClassPathXmlApplicationContext("spring1.xml");
Car myCar = (Car)	ctx.getBean("carObj");
		myCar.startCar();
	
	
FlightEnquiry fe = new FlightEnquiry(); //only one object sufficient 
		fe.findFlight(mum,lon,dt);
		fe.findFlight(mum,fra,dt);
		fe.findFlight(mum,del,dt);
		fe.findFlight(mum,chen,dt);
		
	class FlightEnquiry{ <-- singletonscope
		findFight(s,t,dt) { }
	}
	
		Receptionist		TicketingAgent
		|					|
		|					|
----------------		----------------
|	|	|	|			|	|	|	|
Mum Mum Mum Mum			T1  T2  T3  T3 <-- prototype
Lon Fra Del Chen
1	2	3 	4			Ticket <-- must be on prototype scope
	
			
					Ticket t1 = ctx.getBean("...");
					
			
			
			
		Java Application


*/