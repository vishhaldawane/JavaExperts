package com.java;
public class Car {
    public Car() {
        System.out.println("Car constructed....");
    }
    public void startCar() {
        System.out.println("Car started...");
    }
}
/*
                MySpringProject
                        |
               ------------------------
               |                |
               src              pom.xml
               |                dependencies declared here
           -----------
           |        |
           main     test
           |
          ----------
           |       |
           java    resources
           |        |
         com        spring1.xml <-- your bean configuration file
         |
         java
         |
     ----------
     |        |
    Car     Test



 */