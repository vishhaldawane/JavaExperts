package com.java;
public class HotelReception {
    public HotelReception() {
        System.out.println("HotelReception constructed...");
    }
}
