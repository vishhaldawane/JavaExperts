package com.java;
public class HotelRoom {
    public HotelRoom() {
        System.out.println("HotelRoom constructed (booked) for you...");
    }
}
