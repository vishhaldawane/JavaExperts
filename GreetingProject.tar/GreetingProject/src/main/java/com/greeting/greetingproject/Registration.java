package com.greeting.greetingproject;
/*
Data Access Object - design Pattern


    Pizza       FriedRice       Noodles
        |           |           |kitchen
        |           |           |
    PizzaDAO    FriedRiceDAO    NoodlesDAO
  crud   |      |  crud           |crud
         -------------------------
                |
                Sajana

                    DB
                    |
                    DAO
     [Register + RegistrationDAO + RegistrationDAOImpl]
                    |
                RegistrationServlet

 */
//signup with the website -as a user

public class Registration { //Plain Old Java Object
    private String email;
    private String password;
    private int age; // birthdate should be there , dd mm yy
    private String address;//notice, street, arae, city pin state, country,Address class is required here

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
