package com.greeting.greetingproject;

public class UserNotFoundException extends Exception {
    UserNotFoundException(String str) {
        super(str);
    }
}
