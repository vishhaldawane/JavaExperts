package com.greeting.greetingproject;
//create registration
//view registration
//view all registration
//edit registration
//delete registration
//think in REGISTRAR point of view

import java.util.ArrayList;
//purpose of interface - put mandates
public interface RegistrationDAO {
    void createRegistration(Registration registration);//signup
    Registration findRegistration(String username, String password) throws UserNotFoundException;
    ArrayList<Registration> findAllRegistrations();//admin
    void modifyRegistration(Registration registration);//modify my profile
    void deleteRegistration(Registration registration); // admin
}
//think as an 1. Admin of the website
// and 2. User of the website


