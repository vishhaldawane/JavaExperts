package com.greeting.greetingproject;

import java.sql.*;
import java.util.ArrayList;

public class RegistrationDAOImplementation implements RegistrationDAO {

    Connection connection;

    public RegistrationDAOImplementation() { //constructor would be called while instantiation
        try {
            //1st is to load the driver
            System.out.println("Trying to load the driver...");
            DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
            System.out.println("Driver is loaded.....");

            //MS SQL SERVER --> TWO WAYS TO CONNECT --> VIA WINDOWS AUTHENTICATION
            //OTHER IS USUAL USERNAME AND PASSWORD

            //2nd is to acquire the connection
            System.out.println("Trying to connect to HSQLDB");
            connection = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb", "SA","");
            System.out.println("Connected....."+connection);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    @Override
    public void createRegistration(Registration registration) {
        //insert query is here
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("insert into registration values(?,?,?,?)");
            preparedStatement.setString(1, registration.getEmail());
            preparedStatement.setString(2, registration.getPassword());
            preparedStatement.setInt(3, registration.getAge());
            preparedStatement.setString(4, registration.getAddress());
            int rowsCreated = preparedStatement.executeUpdate();
            System.out.println("Registration created..." + rowsCreated);
            preparedStatement.close();
        }
        catch(SQLException sqlException) {
            System.out.println("SQL Exception : "+sqlException);
        }
        catch(RuntimeException runtimeException) {
            System.out.println("Runtime Exception : "+runtimeException);
        }
        catch(Exception exception) {
            System.out.println("Exception : "+exception);
        }
    }

    @Override
    public Registration findRegistration(String email, String password) throws UserNotFoundException
    {
        //select query
        boolean userFound=false;
        Registration foundRegistration = null;
        try {
            PreparedStatement statement = connection.prepareStatement("select * from registration where email=? and password=?");
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet resultRs = statement.executeQuery();
            if(resultRs.next()) {
                foundRegistration = new Registration();
                foundRegistration.setEmail(resultRs.getString(1));
                foundRegistration.setPassword(resultRs.getString(2));
                foundRegistration.setAge(resultRs.getInt(3));
                foundRegistration.setAddress(resultRs.getString(4));
            }
            else
                throw new UserNotFoundException("User Not found");
        }
        catch(SQLException sqlException) {
            System.out.println("SQL Exception : "+sqlException);
        }
        return foundRegistration;
    }

    @Override
    public ArrayList<Registration> findAllRegistrations() {
        //select query for all records
        return null;
    }

    @Override
    public void modifyRegistration(Registration registration) {
        //update query
    }

    @Override
    public void deleteRegistration(Registration registration) {
        //delete query
    }
}
