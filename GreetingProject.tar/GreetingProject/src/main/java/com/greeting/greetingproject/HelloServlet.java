package com.greeting.greetingproject;

import java.io.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
/*

7 HABITS OF HIGHLY EFFECTIVE PEOPLE - STEPHEN COVEY
------------------PRIVATE VICTORY
1. BE PROACTIVE          - SELF INSPIRATION
2. PUT FIRST THING FIRST - AT LEAST ONE IMPLEMENTATION EVERY DAY
3. BEGIN WITH THE END IN MIND
-----------------------
4. THINK WIN-WIN
-------------- PUBLIC VICTORY
5. SEEK FIRST TO UNDERSTAND THEN TO BE UNDERSTOOD
6. SYNERGY
7. SHARPEN THE SAW
---------------------
    PDF WITH ME - CASE STUDY
    2 PEOPLE IN ONE PROJECT

                                                        IT CLIENTS/NON-IT CLINETS
    U AS AN EMPLOYEE - APPLY FOR THE JOB ---> MNC ----> JP MORGAN -->S/W WITH THE CLIENT
                                                        BOA  - S/W
                                             IT <---->           BRITISHAIRWAYS - S/W

            Domain knowledge            and             Technical Knowledge
            |                                           |           DB
            |                                           |           |
            Airline                                     CoreJava, Web technology, Angular, Hibernate
            Insurance                                   Spring SpringBoot, Git, Agile, Sprints
            Banking
            |                                   LEARN HOW TO RUN THE SWORD, AND NO BATTLE THEN???
       ----------
       |        |
       Admin    EndUser
       |              |
       |             apply for banking account [ html - registration with the bank]
  createBankAccount  login into bankAccount [ html - login into your account ]
  for you            and view balance, [ A dashboard should be given to you ]
                     view payees, perform           -VIEW BALANCE  VIEW PAYEES   TRANSFER  STATEMENTS
                     fund transfer, view
                     monthly statements

    REGISTRATION
    EMAIL               AGE PASSWORD ADDRESS
    rajesh@gmail.com    23  123      Florida
    biswas
    kiran
    suraj
    sajana
    vishhal
    milan
    sushil
    ...
    ..

                 BANK ACCOUNT
                 EMAIL              ACNO    ACBALANCE
                 rajesh@gmail.com   10101   65000
                 biswas             102301
                 kiran              102504

          PAYEE
          email                 PAYEEACNO
          rajesh@gmail.com      102301
          rajesh@gmail.com      102504


          TRANSFER
          FROMACO       TOACC       TRANSFERAMT     TRANSFERDATE
          10101         102301      5000            21-DEC-2020
          10101         102301      7000            25-DEC-2020
          10101         102504      8000            30-DEC-2021

             6 LAYERS

             1. DATABASE LAYER
             2. POJO -
             3. HIBERNATE
             4. MAIN CODE OF THE PROJECT - SERVICE LAYER
             5. SPRING CONTROLLER LAYER
             6. ANGULAR - UI LAYER

 */
@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {
    private String message;

    //is called only once in the lifetime of the servlet
    public void init() {
        System.out.println("init() invoked...");
        message = "Hello World! via message : Vishhal";
    }

    //each time invoked whenever a new request arrives / browser's refresh button is clicked
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("\tdoGet() invoked...");
        response.setContentType("text/html");
        // Hello
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + message + "</h1>");
        out.println("</body></html>");
    }

    public void destroy() {
        System.out.println("destroy() invoked.. ");
    }
}