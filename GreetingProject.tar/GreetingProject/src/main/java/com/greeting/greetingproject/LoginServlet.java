package com.greeting.greetingproject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "LoginServlet", value = "/LoginServlet")
public class LoginServlet extends HttpServlet {
    RegistrationDAOImplementation registrationDAO; //just a reference

    public void init() { /*load driver, connect to db */
        System.out.println("init is called once...");
        registrationDAO = new RegistrationDAOImplementation(); //object created
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userEmail = request.getParameter("myemail");
        String userPassword = request.getParameter("mypassword");
        Registration existingRegistration = null;
        PrintWriter pw = response.getWriter();
        pw.println("<html>");
        pw.println("<body>");
        try {
                existingRegistration = registrationDAO.findRegistration(userEmail,userPassword);
                    pw.println("<h2>Welcome User " + existingRegistration.getEmail() + "</h2>");
                    pw.println("<hr>");
                    pw.println("<h3>Hows your city doing " + existingRegistration.getAddress() + "</h3>");
                    pw.println("<h4>You completed " + existingRegistration.getAge() + " years </h4>");
                    pw.println("<hr>");

                    pw.println("<a href='index.jsp'> Home </a>");
                    pw.println("<a href='Logout.jsp'> Logout </a>");

                    System.out.println("found the registration");

        } catch (UserNotFoundException e) {
            System.out.println(userEmail+" <h1> registration not found : "+e);
            pw.println("<script> alert('not found'); </script>");
            request.getRequestDispatcher("login.html").forward(request,response);
          //  e.printStackTrace();
        }
        pw.println("</body>");
        pw.println("</html>");



    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
