package com.greeting.greetingproject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

/*
Developer structure :

        GreetingProject
            |
       ------------------------------------------
       |               |                 |
       webapp        WEB-INF            src-----+
       |               web.xml           |      |
     --------------------------------   main    test
     |          |               |       |           |
 index.jsp  register.html   login.html  java      java--> test cases
                                        |
                                        com.greeting.greetingproject
                                                        |
                                       -------------------------------
                                       |        |                   |
                                HelloServlet  RegistrationServlet  LoginServlet
                               .java           .java               .java
-------------------------------------------------------------
Deployment structure :
for apache tomcat
        GreetingProject
            |
       ------------------------------------------
       |                    |
       WEB-INF      index.jsp
       |            register.html
      classes       login.html
         |
    com.greeting.greetingproject
             |
    ----------------------------------
    |           |                   |
 HelloServlet  RegistrationServlet  LoginServlet
 .class          .class              .class
                                            300 rooms
                                            database        database
                                                |           |
                        Server      RegistrationServlet | LoginServlet
          apache  +   tomcat [ machine ip + port ] /GreetingProject/index.jsp
                       |
            ----------------------------
            |           |              |
        browser1     browser2         browser 3....







 */
//Association - isA  , hasA, usesA, producesA
@WebServlet(name = "RegistrationServlet", value = "/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    RegistrationDAOImplementation registrationDAO; //just a reference

    public void init() { /*load driver, connect to db */
        System.out.println("init is called once...");
        registrationDAO = new RegistrationDAOImplementation(); //object created
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /*html variable's values are read here*/
        String userEmail = request.getParameter("myemail");
        String userPassword = request.getParameter("mypassword");
        int userAge = Integer.parseInt(request.getParameter("myage"));
        String userAddress = request.getParameter("myaddress");

        /*now we are pushing html values inside the pojo object*/
        Registration newRegistration = new Registration(); //blank POJO
        newRegistration.setEmail(userEmail);
        newRegistration.setPassword(userPassword);
        newRegistration.setAge(userAge);
        newRegistration.setAddress(userAddress);

        registrationDAO.createRegistration(newRegistration);//dao method invoked

        System.out.println("RegistrationServlet has done the registration");
        //store the above variables to preparedStatement to insert
        PrintWriter pw = response.getWriter();
        pw.println("<html>");
            pw.println("<body>");
                    pw.println("<h2>Registration successful");
                    pw.println("<hr>");
                   pw.println("<a href='index.jsp'> Home </a>");
           pw.println("</body>");
        pw.println("</html>");

    }
    public void destroy() { /*close teh connection */}

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
