import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Friend } from './Friend';

@Injectable({
  providedIn: 'root'
})
export class FriendService {

  constructor(private myHttp: HttpClient) { }
  getAllFriendsFromSpring() : Observable<Friend[]> {
      console.log('getting all friends from spring');
      //the below line would talk to Spring's controller -> FriendController
      return this.myHttp.get<Friend[]>("http://localhost:8080/friend/getAllFromDB");
  }

  addFriendToSpring(newFriend: Friend) : Observable<Friend> {
    console.log('adding a friend to spring');
    console.log(newFriend.friendId);
    console.log(newFriend.friendName);
    
    //the below line would talk to Spring's controller -> FriendController
    return this.myHttp.post<Friend>("http://localhost:8080/friend/addFriend/",newFriend);
  }
}
