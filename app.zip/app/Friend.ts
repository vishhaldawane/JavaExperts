export class Friend {
    friendId: number=0; // spelling mismatch wont fetch data from java pojo 
    friendName: string|undefined;
}
//above two fields must match with java pojo fields
