package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Friend;

@Service
public interface FriendService {

	List<Friend> getAllFriendsService();
	List<Friend> getAllFriendsFromDatabaseService();
}
