package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Friend;

@Repository
public interface FriendRepository {
	List<Friend> getAllFriends(); //function to produce all the friends list
	List<Friend> getAllFriendsFromDatabase(); // function to product all the friends from the DB - using spring jdbc
}
