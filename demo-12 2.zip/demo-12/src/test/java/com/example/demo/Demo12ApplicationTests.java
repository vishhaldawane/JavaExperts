package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Friend;
import com.example.demo.layer3.FriendRepositoryImpl;

@SpringBootTest
class Demo12ApplicationTests {

	
	
	@Autowired
	FriendRepositoryImpl friendRepo;
	
	@Test
	void getMyFriendsFromDBTest() {
		
		List<Friend> friendList=friendRepo.getAllFriendsFromDatabase();
		for(Friend theFriend : friendList) {
			System.out.println("Friend "+theFriend.getFriendName());
		}
	}
	
	@Test
	void addFriendToTheDBTest() {
		
		Friend theFriend = new Friend(7,"Jacky");
		friendRepo.addFriend(theFriend);
	}

}
