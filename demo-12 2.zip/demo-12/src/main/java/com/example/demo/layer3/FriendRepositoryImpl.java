package com.example.demo.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Friend;

@Repository
public class FriendRepositoryImpl implements FriendRepository {
	
	@Override
	public List<Friend> getAllFriends() {
		
		ArrayList<Friend> friendList = new ArrayList<Friend>();
		friendList.add(new Friend(1,"Subed"));
		friendList.add(new Friend(2,"Rajesh"));
		friendList.add(new Friend(3,"Europe"));
		friendList.add(new Friend(4,"USA"));
		friendList.add(new Friend(5,"Nepal"));
		friendList.add(new Friend(6,"India"));
		
		
		return friendList;
	}
	
	@Override
	public List<Friend> getAllFriendsFromDatabase() {
		
		List<Friend> friendList=null;
		try {
			friendList = new ArrayList<Friend>();
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			//Class.forName("org.hsqldb.jdbc.JDBCDriver");
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb","SA","");
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from friends");
			while(rs.next()) {
				Friend theFriend = new Friend();
				theFriend.setFriendId(rs.getInt(1));
				theFriend.setFriendName(rs.getString(2));
				friendList.add(theFriend);
			}
		}  catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return friendList;
	}
	
	public void addFriend(Friend theFriend) {
		try {
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			//Class.forName("org.hsqldb.jdbc.JDBCDriver");
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb","SA","");
			PreparedStatement pst = conn.prepareStatement("insert into friends values(?,?)");
			pst.setInt(1,theFriend.getFriendId());
			pst.setString(2, theFriend.getFriendName());
			pst.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
	// 1) arraylist
	// 2) spring + jdbc (select) 
	// 3) spring + hibernate/JPA [ orm ] ( automate the query - hibernate)
	// java persistence api
	