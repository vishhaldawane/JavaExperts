package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.layer2.Friend;
import com.example.demo.layer3.FriendRepository;
import org.springframework.stereotype.Service;

@Service
public class FriendServiceImpl implements FriendService{
	@Autowired
	FriendRepository friendRepo; //automatially the object would be created
	
	@Override
	public List<Friend> getAllFriendsService() {//service
		
		return friendRepo.getAllFriends(); //calling rpeo
	}
	
	@Override
	public List<Friend> getAllFriendsFromDatabaseService() {//service
		
		return friendRepo.getAllFriendsFromDatabase();
	}
	
	public void addFriendService(Friend theFriend) {
		friendRepo.addFriend(theFriend);
	}

}
