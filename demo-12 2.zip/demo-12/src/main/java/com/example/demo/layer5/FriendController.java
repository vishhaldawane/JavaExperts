package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Friend;
import com.example.demo.layer4.FriendService;

@CrossOrigin
@RestController
@RequestMapping("/friend") // top level URI 
public class FriendController {

	@Autowired
	FriendService friendService;
	
	@RequestMapping("/getAll") // http://localhost:8080/friend/getAll
	List<Friend> getAllFriends() {
		return friendService.getAllFriendsService();
	}
	
	@RequestMapping("/getAllFromDB") // http://localhost:8080/friend/getAll
	List<Friend> getAllFriendsFromDB() {
		return friendService.getAllFriendsFromDatabaseService();
	}
	
	@PostMapping("/addFriend") // http://localhost:8080/friend/getAll
	Friend addFriendToDB(@RequestBody Friend theFriend) {
		 friendService.addFriendService(theFriend);
		 return theFriend;
	}
	
	
}
