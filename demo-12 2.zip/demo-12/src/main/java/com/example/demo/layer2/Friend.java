package com.example.demo.layer2;

// 9820 44 34 64



public class Friend { // this is made for the 'friends' table
	
	private int friendId;
	private String friendName;
	
	
	
	public Friend(int friendId, String friendName) {
		super();
		this.friendId = friendId;
		this.friendName = friendName;
	}
	
	public Friend() {
		System.out.println("Friend()..");
	}
	public int getFriendId() {
		return friendId;
	}
	public void setFriendId(int friendId) {
		this.friendId = friendId;
	}
	public String getFriendName() {
		return friendName;
	}
	public void setFriendName(String friendName) {
		this.friendName = friendName;
	}
	
	
	
}
