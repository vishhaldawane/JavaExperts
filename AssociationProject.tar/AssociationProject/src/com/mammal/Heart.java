//whatever happens in life, happens for the good reason
//NOW IMAGINE HOW THESE CLASSES CAN CO-RELATE OR ASSOCIATE WITH EACH OTHER
//THAT IS ISA, HASA, USESA,PRODUCESA
//below example is just a basic WIRING OF ASSOCIATION
package com.mammal;

/**
 * Heart is the important organ of every Human.
 */
public class Heart {
    //DATA + FUNCTION

    /**
     * pumping is the consistent function of a heart
     */
    public void pumping() { }

    /**
     * pumping is the consistent function of a pumping rate
     */
    public void pumping(int rate) { }

    /**
     * beating is also the consistent function with a breating rate
     */
    public void beating(int rate) {

    }
}
