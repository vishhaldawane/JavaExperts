package com.mammal;
/**
 * A Human is the base class for the Poet,Magician,
 * Person, Student, Employee....
 */
public class Human {

    /**
     * Human has a Heart....
     */
    public Heart myHeart = new Heart(); //hasA
}
