package com.arts;
/**
 * A Paper used by the Poet to write the poetry
 */
public class Paper {
    //DATA + FUNCTION

}
