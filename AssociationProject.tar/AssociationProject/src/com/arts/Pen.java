package com.arts;
/**
 * Pen used by the Poet to write the poetry
 */
public class Pen {
    //DATA + FUNCTION
}
