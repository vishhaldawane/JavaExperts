package com.dairy;
/**
 * Use this class to produce the Butter
 */
public class Yogurt {

    /**
     * this method produces the Butter
     *
     * @return
     */
    public Butter churn() {
        Butter b = new Butter();
        return b;
    }
}
