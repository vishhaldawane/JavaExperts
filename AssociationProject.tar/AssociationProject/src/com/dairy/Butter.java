package com.dairy;

/**
 * Apply it on roti, bread, and enjoy....
 */
public class Butter {

    /**
     * this method is used to produce ClarifiedButter
     * @return
     */
    public ClarifiedButter boil() {
        ClarifiedButter cb = new ClarifiedButter();
        return cb;
    }
}
