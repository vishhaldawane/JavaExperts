package com.dairy;

/**
 * super interface for all dairy products
 */
public interface DairyProduct {

}
