package com.dairy;
/**
 * Clarified Butter is good for health
 * at least have a spoon a day while having meal
 */
public class ClarifiedButter // ghee | pure butter
{
    /**
     * enjoy the clarified butter
     */
    public void enjoy() {
        System.out.println("eat a spoon of clarifiedbutter daily for a healthy life...");
    }
}
