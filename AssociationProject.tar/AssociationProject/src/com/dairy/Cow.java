package com.dairy;
/**
 * The source of milk
 */
public class Cow {

    /**
     * this method produces the Milk
     * @return
     */
    public Milk milkACow() { //producesA
        Milk m = new Milk();
        return m; // return means producesA
    }
}
