package com.dairy;

/**
 * this one is thrown from coagulate method of Milk
 */
public class MilkException extends Exception {
}
