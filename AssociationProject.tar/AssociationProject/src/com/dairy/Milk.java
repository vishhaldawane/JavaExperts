package com.dairy;
/**
 * this class is the outcome from a Cow
 */
public class Milk {

    /**
     * this method produces the Yogurt
     * @return
     */
    public Yogurt coagulate() {
        Yogurt y = new Yogurt();
        return y;
    }
}
